# @jerecocc/tracker-ui

Reusable React components extracted from the Hockey Tracker client.

## Usage

Prefer root named imports when you are pulling several components:

```tsx
import { Button, Modal, Select } from '@jerecocc/tracker-ui';
import '@jerecocc/tracker-ui/style.css';
```

For one-off component imports, use the short component entrypoints:

```tsx
import Button from '@jerecocc/tracker-ui/Button';
import Select from '@jerecocc/tracker-ui/Select';
import '@jerecocc/tracker-ui/styles.css';
```

For local development in this repository, the client aliases `@jerecocc/tracker-ui` to this package's `src` folder so component changes are picked up without publishing.

## Build

```bash
npm run build
```

The build emits preserved ES modules and declaration files into `dist/`, so consumers can import from the package root, short component paths such as `@jerecocc/tracker-ui/Button`, or legacy deep component paths such as `@jerecocc/tracker-ui/components/Button/Button`.

## Storybook

Preview package components directly from source while developing:

```bash
npm run storybook
```

Storybook runs at `http://localhost:6006` and updates as component source or stories change. To verify the standalone documentation build, run:

```bash
npm run build-storybook
```

Every exported visual component has its own **Docs** page with a live example, a TypeScript-generated props table, and a copyable TSX usage sample. Component pages are regenerated automatically before Storybook starts or builds; update `src/stories/componentExamples.tsx`, `src/stories/usageSamples.ts`, and the catalog in `scripts/generate-component-docs.mjs` when adding or changing components.
